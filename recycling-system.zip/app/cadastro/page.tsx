"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Recycle, Volume2, HandMetal } from "lucide-react"
import Link from "next/link"

export default function CadastroPage() {
  const [formData, setFormData] = useState({
    nomeCompleto: "",
    dataNascimento: "",
    cpf: "",
    endereco: "",
    cep: "",
    matriculaImovel: "",
    placaAutomovel: "",
  })

  const [audioEnabled, setAudioEnabled] = useState(false)
  const [librasEnabled, setLibrasEnabled] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Dados do cadastro:", formData)
    // Aqui seria implementada a lógica de envio dos dados
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Recycle className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">EcoTroca</h1>
            </Link>

            {/* Controles de Acessibilidade */}
            <div className="flex items-center gap-4">
              <Button
                variant={audioEnabled ? "default" : "outline"}
                size="sm"
                onClick={() => setAudioEnabled(!audioEnabled)}
                className="flex items-center gap-2"
              >
                <Volume2 className="h-4 w-4" />
                Áudio
              </Button>
              <Button
                variant={librasEnabled ? "default" : "outline"}
                size="sm"
                onClick={() => setLibrasEnabled(!librasEnabled)}
                className="flex items-center gap-2"
              >
                <HandMetal className="h-4 w-4" />
                Libras
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-4">Cadastro EcoTroca</h2>
          <p className="text-muted-foreground">Preencha seus dados para começar a reciclar e ganhar pontos</p>
        </div>

        {/* Indicador de Acessibilidade Ativa */}
        {(audioEnabled || librasEnabled) && (
          <Card className="mb-6 border-accent/50 bg-accent/5">
            <CardContent className="pt-6">
              <div className="flex items-center gap-2 text-sm">
                {audioEnabled && (
                  <div className="flex items-center gap-1 text-accent-foreground">
                    <Volume2 className="h-4 w-4" />
                    <span>Audiodescrição ativada</span>
                  </div>
                )}
                {librasEnabled && (
                  <div className="flex items-center gap-1 text-accent-foreground">
                    <HandMetal className="h-4 w-4" />
                    <span>Libras ativado</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Informações Pessoais</CardTitle>
            <CardDescription>Todos os campos são obrigatórios para o cadastro</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nomeCompleto">Nome Completo</Label>
                  <Input
                    id="nomeCompleto"
                    name="nomeCompleto"
                    type="text"
                    value={formData.nomeCompleto}
                    onChange={handleInputChange}
                    placeholder="Digite seu nome completo"
                    required
                    aria-describedby={audioEnabled ? "nome-audio" : undefined}
                  />
                  {audioEnabled && (
                    <div id="nome-audio" className="sr-only">
                      Campo para inserir seu nome completo conforme documento de identidade
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dataNascimento">Data de Nascimento</Label>
                  <Input
                    id="dataNascimento"
                    name="dataNascimento"
                    type="date"
                    value={formData.dataNascimento}
                    onChange={handleInputChange}
                    required
                    aria-describedby={audioEnabled ? "data-audio" : undefined}
                  />
                  {audioEnabled && (
                    <div id="data-audio" className="sr-only">
                      Selecione sua data de nascimento
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="cpf">CPF</Label>
                <Input
                  id="cpf"
                  name="cpf"
                  type="text"
                  value={formData.cpf}
                  onChange={handleInputChange}
                  placeholder="000.000.000-00"
                  required
                  aria-describedby={audioEnabled ? "cpf-audio" : undefined}
                />
                {audioEnabled && (
                  <div id="cpf-audio" className="sr-only">
                    Digite seu CPF com pontos e traço
                  </div>
                )}
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="endereco">Endereço Completo</Label>
                  <Input
                    id="endereco"
                    name="endereco"
                    type="text"
                    value={formData.endereco}
                    onChange={handleInputChange}
                    placeholder="Rua, número, bairro, cidade"
                    required
                    aria-describedby={audioEnabled ? "endereco-audio" : undefined}
                  />
                  {audioEnabled && (
                    <div id="endereco-audio" className="sr-only">
                      Digite seu endereço completo incluindo rua, número, bairro e cidade
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cep">CEP</Label>
                  <Input
                    id="cep"
                    name="cep"
                    type="text"
                    value={formData.cep}
                    onChange={handleInputChange}
                    placeholder="00000-000"
                    required
                    aria-describedby={audioEnabled ? "cep-audio" : undefined}
                  />
                  {audioEnabled && (
                    <div id="cep-audio" className="sr-only">
                      Digite seu CEP com traço
                    </div>
                  )}
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="matriculaImovel">Matrícula do Imóvel</Label>
                  <Input
                    id="matriculaImovel"
                    name="matriculaImovel"
                    type="text"
                    value={formData.matriculaImovel}
                    onChange={handleInputChange}
                    placeholder="Digite a matrícula do imóvel"
                    required
                    aria-describedby={audioEnabled ? "matricula-audio" : undefined}
                  />
                  {audioEnabled && (
                    <div id="matricula-audio" className="sr-only">
                      Digite o número da matrícula do seu imóvel conforme conta de luz
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="placaAutomovel">Placa do Automóvel</Label>
                  <Input
                    id="placaAutomovel"
                    name="placaAutomovel"
                    type="text"
                    value={formData.placaAutomovel}
                    onChange={handleInputChange}
                    placeholder="ABC-1234 (opcional)"
                    aria-describedby={audioEnabled ? "placa-audio" : undefined}
                  />
                  {audioEnabled && (
                    <div id="placa-audio" className="sr-only">
                      Digite a placa do seu automóvel. Este campo é opcional
                    </div>
                  )}
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 pt-6">
                <Button type="submit" className="flex-1 bg-primary hover:bg-primary/90">
                  Finalizar Cadastro
                </Button>
                <Button type="button" variant="outline" className="flex-1 bg-transparent">
                  <Link href="/">Voltar</Link>
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Informações sobre Acessibilidade */}
        <Card className="mt-8 border-muted">
          <CardHeader>
            <CardTitle className="text-lg">Recursos de Acessibilidade</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm text-muted-foreground">
              <div className="flex items-start gap-2">
                <Volume2 className="h-4 w-4 mt-0.5 text-accent-foreground" />
                <div>
                  <strong>Audiodescrição:</strong> Ative para ouvir descrições detalhadas dos campos do formulário
                </div>
              </div>
              <div className="flex items-start gap-2">
                <HandMetal className="h-4 w-4 mt-0.5 text-accent-foreground" />
                <div>
                  <strong>Libras:</strong> Ative para acessar interpretação em Língua Brasileira de Sinais
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
