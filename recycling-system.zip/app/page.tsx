import { Recycle, Leaf, Award, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Recycle className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">ReciclamaisBrasil</h1>
            </div>
            <nav className="hidden md:flex items-center gap-6">
              <Link href="#como-funciona" className="text-muted-foreground hover:text-foreground transition-colors">
                Como Funciona
              </Link>
              <Link href="#recompensas" className="text-muted-foreground hover:text-foreground transition-colors">
                Recompensas
              </Link>
              <Link href="#cadastro" className="text-muted-foreground hover:text-foreground transition-colors">
                Cadastro
              </Link>
              <Button variant="outline" size="sm">
                Entrar
              </Button>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center max-w-4xl">
          <div className="flex justify-center mb-6">
            <Badge variant="secondary" className="bg-accent text-accent-foreground px-4 py-2">
              Sistema de Reciclagem Inteligente
            </Badge>
          </div>
          <h2 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
            Transforme seus <span className="text-primary">resíduos</span> em{" "}
            <span className="text-accent">benefícios</span>
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Recicle materiais e ganhe pontos que podem ser trocados por descontos na conta de luz, transporte público
            gratuito e muito mais.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90">
              Começar Agora
            </Button>
            <Button variant="outline" size="lg">
              Saiba Mais
            </Button>
          </div>
        </div>
      </section>

      {/* Como Funciona */}
      <section id="como-funciona" className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-foreground mb-4">Como Funciona</h3>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Sistema simples e eficiente para transformar reciclagem em benefícios reais
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <Recycle className="h-8 w-8 text-primary" />
                </div>
                <CardTitle>1. Colete Materiais</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Separe plásticos, papéis, papelão e eletrônicos em sua casa ou empresa
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="mx-auto w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center mb-4">
                  <Award className="h-8 w-8 text-accent-foreground" />
                </div>
                <CardTitle>2. Ganhe Pontos</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Cada quilo de material reciclado gera pontos em sua conta</CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="mx-auto w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center mb-4">
                  <Users className="h-8 w-8 text-secondary" />
                </div>
                <CardTitle>3. Troque por Benefícios</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Use seus pontos para obter descontos e benefícios exclusivos</CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Tabela de Pontos */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-foreground mb-4">Tabela de Pontos</h3>
            <p className="text-muted-foreground">Veja quantos pontos você ganha com cada tipo de material</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="border-primary/20">
              <CardHeader className="text-center">
                <CardTitle className="text-primary">Plástico</CardTitle>
              </CardHeader>
              <CardContent className="text-center space-y-2">
                <div className="text-3xl font-bold text-foreground">100</div>
                <div className="text-sm text-muted-foreground">pontos por kg</div>
                <div className="text-lg font-semibold text-primary">R$ 7,50</div>
              </CardContent>
            </Card>

            <Card className="border-accent/20">
              <CardHeader className="text-center">
                <CardTitle className="text-accent-foreground">Papel/Papelão</CardTitle>
              </CardHeader>
              <CardContent className="text-center space-y-2">
                <div className="text-3xl font-bold text-foreground">90</div>
                <div className="text-sm text-muted-foreground">pontos por kg</div>
                <div className="text-lg font-semibold text-accent-foreground">R$ 7,00</div>
              </CardContent>
            </Card>

            <Card className="border-secondary/20">
              <CardHeader className="text-center">
                <CardTitle className="text-secondary">Eletrônicos</CardTitle>
              </CardHeader>
              <CardContent className="text-center space-y-2">
                <div className="text-3xl font-bold text-foreground">200</div>
                <div className="text-sm text-muted-foreground">pontos por kg</div>
                <div className="text-lg font-semibold text-secondary">R$ 12,50</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Recompensas */}
      <section id="recompensas" className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-foreground mb-4">Recompensas Disponíveis</h3>
            <p className="text-muted-foreground">Troque seus pontos por benefícios incríveis</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-2">
                  <Leaf className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-lg">Desconto Conta de Luz</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="text-2xl font-bold text-primary">500 pontos</div>
                  <div className="text-sm text-muted-foreground">R$ 50,00 de desconto</div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center mb-2">
                  <Users className="h-6 w-6 text-accent-foreground" />
                </div>
                <CardTitle className="text-lg">Transporte Público</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="text-2xl font-bold text-accent-foreground">1000 pontos</div>
                  <div className="text-sm text-muted-foreground">Passe livre por 2 semanas</div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mb-2">
                  <Award className="h-6 w-6 text-secondary" />
                </div>
                <CardTitle className="text-lg">Eventos Culturais</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="text-2xl font-bold text-secondary">2500 pontos</div>
                  <div className="text-sm text-muted-foreground">Ingresso cinema/cultura</div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-2">
                  <Recycle className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-lg">Créditos Mercado</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="text-2xl font-bold text-primary">5000 pontos</div>
                  <div className="text-sm text-muted-foreground">R$ 400,00 em créditos</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center max-w-3xl">
          <h3 className="text-3xl font-bold text-foreground mb-4">Pronto para começar a reciclar?</h3>
          <p className="text-xl text-muted-foreground mb-8">
            Faça seu cadastro agora e comece a transformar seus resíduos em benefícios reais
          </p>
          <Button size="lg" className="bg-primary hover:bg-primary/90">
            <Link href="/cadastro">Fazer Cadastro</Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/30 py-12 px-4">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <Recycle className="h-6 w-6 text-primary" />
              <span className="font-semibold text-foreground">ReciclamaisBrasil</span>
            </div>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>Acessibilidade: Libras e Audiodescrição disponíveis</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
